export enum Status {
    ToDo = "To do",
    InProgress = "In progress",
    Done="Done",
}
