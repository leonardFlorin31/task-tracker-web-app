import { Component, Input } from '@angular/core';
import {MatButtonModule} from '@angular/material/button';
import {MatCardModule} from '@angular/material/card';
import { Task } from '../task';
import { CommonModule, NgFor } from '@angular/common';
import { TaskCardComponent } from '../task-card/task-card.component';
import { TaskService } from '../services/task.service';

@Component({
  selector: 'app-task-grid',
  standalone: true,
  imports: [MatCardModule, MatButtonModule, CommonModule, NgFor, TaskCardComponent],
  providers: [TaskService],
  templateUrl: './task-grid.component.html',
  styleUrl: './task-grid.component.scss'
})
export class TaskGridComponent {
  
  taskList: Task[];

  constructor(
    private taskService: TaskService,
  ) {}

  onDeleteClicked(task) {
    const index = this.taskList.indexOf(task); // Find the index of the task in the array
    if (index !== -1) {
      this.taskList.splice(index, 1); // Remove the task from the array using splice
      console.log("delete");
    }
  }
}
