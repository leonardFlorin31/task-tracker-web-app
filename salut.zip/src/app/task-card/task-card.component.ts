import { Component, EventEmitter, Input, Output } from '@angular/core';
import {MatButtonModule} from '@angular/material/button';
import {MatCardModule} from '@angular/material/card';
import { Task } from '../task';
import { CommonModule, NgFor } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-task-card',
  standalone: true,
  imports: [MatCardModule, MatButtonModule, CommonModule, NgFor, MatIconModule],
  templateUrl: './task-card.component.html',
  styleUrl: './task-card.component.scss'
})
export class TaskCardComponent {
  @Output() deleteClicked = new EventEmitter<Task>();
  @Input() task: Task;
  
  deleteTask(task) {
    this.deleteClicked.emit(task);
  }

  editTask(task) {
    console.log(task);
  }
}
