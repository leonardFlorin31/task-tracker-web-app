import { Component, Input, OnInit } from '@angular/core';
import { Task } from '../task';
import { CommonModule } from '@angular/common';
import { FilterComponent } from '../filter/filter.component';
import { Status } from '../status-enum';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule, MatFabButton, MatMiniFabButton } from '@angular/material/button';
import { TaskService } from '../services/task.service';

@Component({
  selector: 'app-task-list',
  standalone: true,
  imports: [CommonModule, FilterComponent, MatIconModule, MatButtonModule],
  providers: [TaskService],
  templateUrl: './task-list.component.html',
  styleUrl: './task-list.component.scss'
})
export class TaskListComponent implements OnInit{
  
  taskList: Task[];
  filteredTasks: Task[];

  constructor(
    private taskService: TaskService,
  ) {}
  
  deleteTask(task) {
    const index = this.taskList.indexOf(task); // Find the index of the task in the array
    if (index !== -1) {
      this.taskList.splice(index, 1); // Remove the task from the array using splice
      console.log("delete");
    }
  }

  editTask(task) {
    console.log(task);
  }

  ngOnInit(): void {
    this.filteredTasks = this.taskList;
  }

  handleStatusSelected(status): void {
    this.filteredTasks = this.taskList.filter((task) => task.status == status)
  }
}
