import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { TaskService } from '../services/task.service';

@Component({
  selector: 'app-add-task',
  standalone: true,
  imports: [FormsModule, RouterModule],
  providers: [TaskService],
  templateUrl: './add-task.component.html',
  styleUrl: './add-task.component.scss'
})
export class AddTaskComponent {
  taskName: string;
  taskDescription: string;
  
  constructor(private router: Router, private taskService: TaskService) {}

  onCancel() {
    this.router.navigate(['/']);
    console.log('cancel');
  }

  onSubmit() {
    console.log('Task Name:', this.taskName);
    console.log('Description:', this.taskDescription);
  }
}
