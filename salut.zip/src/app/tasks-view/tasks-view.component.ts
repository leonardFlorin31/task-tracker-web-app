import { Component } from '@angular/core';
import { TaskGridComponent } from '../task-grid/task-grid.component';
import { Task } from '../task';
import { Status } from '../status-enum';
import { TaskListComponent } from '../task-list/task-list.component';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-tasks-view',
  standalone: true,
  imports: [TaskGridComponent, TaskListComponent, CommonModule, MatIconModule],
  templateUrl: './tasks-view.component.html',
  styleUrl: './tasks-view.component.scss'
})
export class TasksViewComponent {
  taskList: Task[] = [{id: '1', title: 'wow', description: 'haha', status: Status.ToDo},
                      {id: '2', title: 'hello', description: 'hahahehe', status: Status.InProgress},
                      {id: '3', title: 'another task', description: 'this is a task', status: Status.Done},
                      {id: '4', title: 'task', description: 'this is another task', status: Status.Done}];
  isList: boolean = true;
}
